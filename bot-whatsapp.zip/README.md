
<h1 align="center">Bem vindo ao Bruce, O bot de WhatsApp</h1>

> Obrigado [https://github.com/jhowbhz/bot-whatsapp](Jhonathan) por esse código incrível!

### 🤖 [Fale com o bot](https://wa.me/+5521999222644)

### 👥 [Grupo de bots](https://chat.whatsapp.com/CETtCOiMt1FA9xMX3YpWMt)

## O que eu fiz?

- Removi interação com grupos (superficialmente) e todos os comandos exclusivos para grupos.
- Adicionei "Quantos dias falta para o aniversário".
- Adicionei suporte ao multi-devices.

## Instalando o bot: 📚

```bash
git clone https://github.com/kaualandi/bot-whatsapp.git
```

```bash
cd bot-whatsapp
```

```bash
npm install --unsafe-perm
```

```bash
npm install -y pm2 -g
```

## Forma de usar: 💫

Depois de clonar instalar o projeto, basta digitar o seguinte, e ler o QR Code em seguida... 

```bash
npm start
```

Leu o QR Code? Tudo certo!

## O que ele pode fazer?

- Envia Memes
- Envia Stickers
- Envia Stickert Gif
- Envia Audios
- Fala texto digitado
- Tradutor
- Horoscopo
- Busca Concursos por estado
- Busca CEP Brasil
- Busca Clima por cidade
- Busca Memes e Escreve
- Busca Memes e Escreve
- Calcula aniversários

E muito mais....

### Comando inicial: ☕

```bash
oi Bruce
```

### Merecidos créditos: 🏆

O projeto foi baseado no seguinte repositório https://github.com/MhankBarBar/whatsapp-bot
Clonado de: [https://github.com/jhowbhz/bot-whatsapp](jhowbhz)